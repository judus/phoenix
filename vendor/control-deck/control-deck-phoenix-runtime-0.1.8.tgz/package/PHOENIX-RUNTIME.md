# Control Deck embedded runtime for PHOENIX

This package is a purpose-built subset of Control Deck for use as part of PHOENIX. It does not
contain the standalone Control Deck application, user interface, styles, launchers, installers,
sound playback, or command-runner integration.

It is not a standalone Control Deck distribution. See LICENSE and the PHOENIX distribution terms.
